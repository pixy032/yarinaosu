
package jp.arm.jmater.component;

import java.io.File;

import org.apache.jmeter.engine.StandardJMeterEngine;
import org.apache.jmeter.reporters.ResultCollector;
import org.apache.jmeter.reporters.Summariser;
import org.apache.jmeter.save.SaveService;
import org.apache.jmeter.util.JMeterUtils;
import org.apache.jorphan.collections.HashTree;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class StratJmeter {

    public static void run(String home, String in, String out) throws Exception {

        StandardJMeterEngine jmeter = new StandardJMeterEngine();
        // jmaterインストールパス
        JMeterUtils.setJMeterHome(home);
        // jmeter.propertiesを読み込む
        JMeterUtils.loadJMeterProperties(home + "/bin/jmeter.properties");
        JMeterUtils.initLocale();
        // jmeterスプリットを設定
        SaveService.loadProperties();
        File jmx = new File(in);
        HashTree loadTree = SaveService.loadTree(jmx);
        // 実行ログの収集と出力
        String summariserName = JMeterUtils.getPropDefault("summariser.name", "summary");
        Summariser summer = new Summariser(summariserName);
        ResultCollector summerlogger = new ResultCollector(summer);
        summerlogger.setFilename(out);
        loadTree.add(loadTree.getArray(), summerlogger);
        // 実行
        jmeter.configure(loadTree);
        jmeter.run();
        log.info("jmeter実行完了");
    }

}
