
package jp.arm.jmater.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;

@Configuration
@EnableJms
public class JmsListenerConfig {

    @Value("${amazon-settings.accessKey}")
    private String accessKey;
    @Value("${amazon-settings.secretKey}")
    private String secretKey;
    @Value("${amazon-settings.region}")
    private String region;
    @Value("${amazon-settings.concurrency}")
    private String concurrency;

    @Bean
    public DefaultJmsListenerContainerFactory jmsListenerContainerFactory() {

        ProviderConfiguration providerConfiguration = new ProviderConfiguration();
        BasicAWSCredentials awsCreds = new BasicAWSCredentials(this.accessKey, this.secretKey);
        SQSConnectionFactory sqsConnectionFactory = new SQSConnectionFactory(providerConfiguration,
                AmazonSQSClientBuilder.standard().withRegion(this.region)
                        .withCredentials(new AWSStaticCredentialsProvider(awsCreds)));
        DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setConnectionFactory(sqsConnectionFactory);
        factory.setConcurrency(this.concurrency);
        return factory;
    }

}
