
package jp.arm.jmater.listener;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.arm.jmater.component.StratJmeter;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class Listener {

    @Autowired
    private StratJmeter stratJmeter;

    @JmsListener(destination = "${amazon-settings.sqs-queue}")
    public void message(String message) {

        String home = null;
        String in = null;
        String out = null;

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> para = objectMapper.readValue(message, Map.class);
            home = para.get("home").toString();
            in = para.get("in").toString();
            out = para.get("out").toString();
        } catch (Exception e) {
            log.error("wrong parameter");
            log.error(e.toString());
            return;
        }

        try {
            stratJmeter.run(home, in, out);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
